import express from 'express'
import cookieParser from 'cookie-parser'
import userRoutes from './routes/userRoutes.js'
import authRoutes from './routes/authRoutes.js'
import authMiddleware from './middleware/auth.js'
const app = express()
// MIDDLEWARE
app.use(express.json())
app.use(cookieParser())
// RUTAS
app.use('/api/auth/', authRoutes)
// RUTAS PROTEGIDAS
app.use('/api/', authMiddleware, userRoutes)
// MENSAJE BIENVENIDA
app.get('/', (req, res) => {
    res.json('Bienvenido a la API del club de Rol Thorondor')
})
// COMENZAR A ESCUCHAR POR EL PUERTO SELECCIONADO
app.listen(process.env.PORT, () => {
    console.log(`Servidor corriendo en 'http:/localhost:${process.env.PORT}'`)
})
