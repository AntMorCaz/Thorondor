export default function checkAccess (requiredAccessLevel){
    return (req, res, next) => {
        if (!req.user) {
            return res.status(403).json({ message: 'No user data found' });
        }

        const { access } = req.user;
        if (access < requiredAccessLevel) {
            return res.status(403).json({ message: 'Insufficient permissions' });
        }

        next();
    };
};

