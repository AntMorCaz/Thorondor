import jwt from 'jsonwebtoken'
import 'dotenv/config'
export default function authMiddleware (req, res, next){
    req.session = {user:null}
    const token = req.cookies.access_token
    if (!token) {
        return res.status(401).json({ message: 'Autorización rechazada' })
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET)
        req.session.user = decoded
        next()
    } catch (err) {
        req.session.user = null
        res.status(401).json({ message: 'Token inválido o caducado' })
    }
}
