import express from 'express'
import Article from '../models/articleModel.js'
import checkAccess from '../middleware/accessControl.js'
import User from '../models/userModel.js'
import Loan from '../models/loanModel.js'
const router = express.Router();
// Ruta protegida para obtener todos los usuarios (requiere acceso nivel 4)
router.get('/users', checkAccess(4), async (req, res) => {
    try {
        const userService = new User()
        const users = await userService.getAllUsers()
        res.json(users)
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para modificar un usuario (requiere acceso nivel 4)
router.post('/user/modify/', checkAccess(4), async (req, res) => {
    const params = { 
        codigo_socio, nombre, apellidos, correo_electronico, contraseña, direccion, acceso
    } = req.body

    // Verificar si se proporcionó una contraseña antes de intentar hashearla
    if (params.contraseña) {
        params.contraseña = await bcrypt.hash(params.contraseña, 10)
    }

    if (!params.codigo_socio || (!params.nombre && !params.apellidos && !params.correo_electronico && !params.contraseña && !params.direccion && !params.acceso)) {
        return res.status(400).json({ message: 'Debe proporcionar un ID y al menos un campo a modificar' })
    }

    try {
        const userService = new User()
        await userService.modifyUser(params);
        res.status(201).json({ message: 'Socio modificado correctamente' })
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'Error del servidor' })
    }
})


// Ruta protegida para eliminar un usuario (requiere acceso nivel 4)
router.delete('/user/delete/:id', checkAccess(4), async (req, res) => {
    const { id } = req.params

    try {
        const userService = new User()
        const rowsAffected = await userService.deleteUser(id)
        if (rowsAffected === 0) {
            return res.status(404).json({ message: 'Usuario no encontrado' })
        }
        res.status(200).json({ message: 'Usuario eliminado con éxito' })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para obtener un artículo por ID (requiere acceso nivel 1)
router.get('/article/:id', checkAccess(1), async (req, res) => {
    const { id } = req.params

    try {
        const articleService = new Article()
        const article1 = await articleService.getArticleById(id);
        res.status(200).json(article1);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para obtener artículos (requiere acceso nivel 2)
router.get('/articles', checkAccess(1), async (req, res) => {
    const { titulo, categoria, saga } = req.query

    try {
        const articleService = new Article()
        const [articles] = await articleService.findArticles({ titulo, categoria, saga })
        res.status(200).json(articles)
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para crear un nuevo artículo (requiere acceso nivel 3)
router.post('/article/create', checkAccess(3), async (req, res) => {
    const { titulo, categoria, descripcion, autor, saga } = req.body

    if (!titulo || !categoria) {
        return res.status(400).json({ message: 'Un artículo debe tener al menos un título y una categoría' })
    }

    try {
        const articleService = new Article()
        const article1 = await articleService.createArticle({ titulo, categoria, descripcion, autor, saga })
        res.status(201).json({ message: 'Artículo creado correctamente', article1 })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para modificar un artículo (requiere acceso nivel 3)
router.post('/article/modify', checkAccess(3), async (req, res) => {
    const { codigo_articulo, titulo, categoria, descripcion, autor, saga, estado } = req.body

    if (!codigo_articulo || (!titulo && !categoria && !descripcion && !autor && !saga && !estado)) {
        return res.status(400).json({ message: 'Debe proporcionar un ID y al menos un campo a modificar' })
    }

    try {
        const articleService = new Article()
        const rowsAffected = await articleService.modifyArticle({ codigo_articulo, titulo, categoria, descripcion, autor, saga, estado })
        res.status(201).json({ message: 'Artículo modificado correctamente: ?', rowsAffected })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta protegida para eliminar un artículo (requiere acceso nivel 3)
router.delete('/article/delete/:id', checkAccess(3), async (req, res) => {
    const { id } = req.params

    try {
        const articleService = new Article()
        const rowsAffected = await articleService.deleteArticle(id)
        if (rowsAffected === 0) {
            return res.status(404).json({ message: 'Artículo no encontrado' })
        }
        res.status(200).json({ message: 'Artículo eliminado con éxito' })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Crear un nuevo préstamo
router.post('/loan', checkAccess(2), async (req, res) => {
    const { socio, articulo, observaciones } = req.body
    try {
        const articleService = new Article()
        const article1 = await articleService.getArticleById(articulo)
        if(article1.disponible){
            const loanService = new Loan()
            const loanId = await loanService.createLoan(socio, articulo, observaciones)
            
            // Corregir el método para actualizar disponibilidad del artículo
            await articleService.modifyArticle({ codigo_articulo: articulo, disponibilidad: 0 })

            res.status(201).json({ message: 'Préstamo creado correctamente', codigo_prestamo: loanId })
        } else {
            res.status(500).json({ message: 'Artículo no disponible' })
        }

    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }    
})

// Obtener un préstamo por ID
router.post('/loan/return/:codigo_prestamo', checkAccess(2), async (req, res) => {
    try {
        const articleService = new Article()
        const loanService = new Loan()
        const loan1 = await loanService.getLoanById(req.params.codigo_prestamo)
        if (!loan1) {
            return res.status(404).json({ message: 'Préstamo no encontrado' })
        }
        await loanService.returnLoan(req.params.codigo_prestamo)
        await articleService.modifyArticle({ codigo_articulo: loan1.articulo, disponibilidad: 1 })
        res.status(200).json({ message: 'Artículo devuelto correctamente' })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})


// Obtener todos los préstamos
router.get('/loans', checkAccess(3), async (req, res) => {
    try {
        const loanService = new Loan()
        const [loans] = await loanService.getAllLoans()
        res.json(loans);
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Obtener préstamos de un socio específico
router.get('/loans/socio/:socio', checkAccess(2), async (req, res) => {
    try {
        const loanService = new Loan()
        const loans = await loanService.getLoansBySocio(req.params.socio)
        res.json(loans)
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Devolver un artículo prestado
router.post('/loan/return/:codigo_prestamo', checkAccess(2), async (req, res) => {
    try {
        const articleService = new Article()
        const loanService = new Loan()
        const loan1 = await loanService.getLoanById(req.params.codigo_prestamo)
        if (!loan1) {
            return res.status(404).json({ message: 'Préstamo no encontrado' })
        }
        await loanService.returnLoan(req.params.codigo_prestamo)
        await articleService.modifyArticle({ codigo_articulo: loan.articulo, disponibilidad: 1 })
        res.status(200).json({ message: 'Artículo devuelto correctamente' })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

export default router
