import express from 'express'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import 'dotenv/config'
import User from '../models/userModel.js'

const router = express.Router()

// Ruta para el registro
router.post('/register', async (req, res) => {
    const { nombre, apellidos, correo_electronico, contraseña } = req.body

    if (!correo_electronico || !contraseña || !nombre || !apellidos) {
        return res.status(400).json({ message: 'Todos los campos son requeridos' })
    }

    // Validating data types and length before database access
    if (typeof correo_electronico !== 'string' || typeof contraseña !== 'string' || correo_electronico.length < 3 || contraseña.length < 3) {
        return res.status(400).json({ message: 'El correo electrónico y la contraseña deben ser cadenas de texto con al menos 3 caracteres' });
    }

    try {
        const userService = new User()
        let user = await userService.getUserByUsername(correo_electronico)
        if (user) {
            return res.status(400).json({ message: 'El usuario ya existe' })
        }
        const hashedPassword = await bcrypt.hash(contraseña, 10)
        const userId = await userService.createUser(nombre, apellidos, correo_electronico, hashedPassword)
        res.status(201).json({ message: 'Usuario registrado con éxito', userId })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta para el inicio de sesión
router.post('/login', async (req, res) => {
    const { correo_electronico, contraseña } = req.body

    const cookieToken = req.cookies['access_token'];
    if(cookieToken) {
        return res.status(500).json({message: 'Ya tienes una sesión activa'})
    }

    if (!correo_electronico || !contraseña) {
        return res.status(400).json({ message: 'Todos los campos son requeridos' })
    }

    // Valida datos
    if (typeof correo_electronico !== 'string' || typeof contraseña !== 'string' || correo_electronico.length < 3 || contraseña.length < 3) {
        return res.status(400).json({ message: 'El correo electrónico y la contraseña deben ser cadenas de texto con al menos 3 caracteres' });
    }

    try {
        const userService = new User()
        const user = await userService.getUserByUsername(correo_electronico)
        if (!user) {
            return res.status(400).json({ message: 'Credenciales incorrectas' })
        }
        const isMatch = await bcrypt.compare(contraseña, user.contraseña)
        if (!isMatch) {
            return res.status(400).json({ message: 'Credenciales incorrectas' })
        }
        const token = jwt.sign({ 
            codigo_socio: user.codigo_socio, 
            nombre: user.nombre, 
            apellidos: user.apellidos, 
            acceso: user.acceso 
        }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE })

        res.cookie('access_token', token, { httpOnly: true, maxAge: 1000 * 60 * 60 })
        res.status(200).json({ message: 'Usuario y Contraseña correctos' })
    } catch (err) {
        console.error(err.message)
        res.status(500).json({ message: 'Error del servidor' })
    }
})

// Ruta para cerrar sesión
router.post('/logout', async (req, res) => {
    res.clearCookie('access_token').json({ message: 'Sesión cerrada' })
})

export default router;
