import pool from '../db.js'

class Loan{

    constructor(){}

    // Crear un nuevo préstamo
async createLoan(socio, articulo, observaciones = ''){
    const currentDate = new Date()
    const returnDate = new Date(currentDate)
    returnDate.setDate(currentDate.getDate() + 30)

    const query = 'INSERT INTO prestamo (socio, articulo, fecha_salida, fecha_devolucion, observaciones) VALUES (?, ?, ?, ?, ?)'
    const [result] = await pool.query(query, [socio, articulo, fecha_salida, fecha_devolucion, observaciones])
    return result.insertId
};

// Obtener un préstamo por ID
async getLoanById(codigo_prestamo){
    const [rows] = await pool.query('SELECT * FROM prestamo WHERE codigo_prestamo = ?', [codigo_prestamo])
    return rows[0]
};
async getLoansByUser(socio){
    const [rows] = await pool.query('SELECT * FROM prestamo WHERE socio = ?', [socio])
    return rows;
};
// Obtener todos los préstamos
async getAllLoans(){
    const [rows] = await pool.query('SELECT * FROM prestamo')
    return rows;
};

// Modificar un préstamo
async modifyLoan(codigo_prestamo, estado, fecha_entrada, observaciones){
    const fields = []
    const values = []

    if (estado) {
        fields.push('estado = ?')
        values.push(estado)
    }
    if (fecha_entrada) {
        fields.push('fecha_entrada = ?')
        values.push(fecha_entrada)
    }
    if (observaciones) {
        fields.push('observaciones = ?')
        values.push(observaciones)
    }

    if (fields.length === 0) {
        throw new Error('No hay campos para actualizar')
    }

    values.push(codigo_prestamo)
    const query = `UPDATE prestamo SET ${fields.join(', ')} WHERE codigo_prestamo = ?`
    const [result] = await pool.query(query, values)
    return result.affectedRows
}

    // Eliminar un préstamo
    async deleteLoan(codigo_prestamo){
        const [result] = await pool.query('DELETE FROM prestamo WHERE codigo_prestamo = ?', [codigo_prestamo])
        return result.affectedRows
    }
}
export default Loan