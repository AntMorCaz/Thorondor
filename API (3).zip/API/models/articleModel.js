import pool from '../db.js'
class Article{

    constructor(){}
    // Buscar artículos por palabra clave
    async findArticles(params){
        const { titulo, categoria, descripcion, autor, saga } = params
        const queryParts = []
        const queryValues = []

        if (titulo) {
            queryParts.push('titulo LIKE ?')
            queryValues.push(`%${titulo}%`)
        }
        if (descripcion) {
            queryParts.push('descripcion LIKE ?')
            queryValues.push(`%${descripcion}%`)
        }
        if (saga) {
            queryParts.push('saga LIKE ?')
            queryValues.push(`%${saga}%`)
        }
        if (autor) {
            queryParts.push('autor LIKE ?')
            queryValues.push(`%${autor}%`)
        }
        if (categoria) {
            queryParts.push('categoria LIKE ?')
            queryValues.push(`%${categoria}%`)
        }

        const query = `SELECT * FROM articulo${queryParts.length ? ' WHERE ' + queryParts.join(' OR ') : ''} ORDER BY disponible`
        const [rows] = await pool.query(query, queryValues)
        return rows
    };

// Obtener artículo por ID
    async getArticleById (id){
        const [rows] = await pool.query('SELECT * FROM articulo WHERE codigo_articulo = ?', id)
        return rows[0]
    }

// Crear un artículo
    async createArticle(titulo, categoria, descripcion, autor, saga){
        const fields = ['titulo', 'categoria']
        const values = [titulo, categoria]
        const placeholders = ['?', '?']

        if (descripcion) {
            fields.push('descripcion')
            values.push(descripcion)
            placeholders.push('?')
        }
        if (autor) {
            fields.push('autor')
            values.push(autor)
            placeholders.push('?')
        }
        if (saga) {
            fields.push('saga')
            values.push(saga)
            placeholders.push('?')
        }

        const query = `INSERT INTO articulo (${fields.join(', ')}) VALUES (${placeholders.join(', ')})`
        const [result] = await pool.query(query, values)
        return result.insertId
    }

// Modificar un artículo
    async modifyArticle(params) {
        const { numero_serie, titulo, categoria, descripcion, autor, saga, estado, disponibilidad } = params
        const fields = []
        const values = []

        if (titulo) {
            fields.push('titulo = ?')
            values.push(titulo)
        }
        if (categoria) {
            fields.push('categoria = ?')
            values.push(categoria)
        }
        if (descripcion) {
            fields.push('descripcion = ?')
            values.push(descripcion)
        }
        if (autor) {
            fields.push('autor = ?')
            values.push(autor)
        }
        if (saga) {
            fields.push('saga = ?')
            values.push(saga)
        }
        if (estado) {
            fields.push('estado = ?')
            values.push(estado)
        }
        if (disponibilidad) {
            fields.push('disponibilidad = ?')
            values.push(disponibilidad)
        }

        if (fields.length === 0) {
            throw new Error('No hay campos para actualizar')
        }

        values.push(numero_serie)
        const query = `UPDATE articulo SET ${fields.join(', ')} WHERE codigo_articulo = ?`
        const [result] = await pool.query(query, values)
        return result.affectedRows
    }

// Obtener todos los artículos
    async getAllArticles(){
        const [rows] = await pool.query('SELECT * FROM articulo')
        return rows
    }

// Eliminar un artículo
    async deleteArticle (numero_serie){
        const [result] = await pool.query('DELETE FROM articulo WHERE codigo_articulo = ?', id)
        return result.affectedRows
    }
}
export default Article
