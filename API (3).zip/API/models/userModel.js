import pool from '../db.js'

class User{
    constructor(){

    }
    // Obtener un usuario por ID
    async getUserById(id){
        const [rows] = await pool.query('SELECT * FROM socio WHERE codigo_socio = ?', [id])
        return rows[0]
    }

    // Obtener un usuario por correo electrónico
    async getUserByUsername(email){
        const [rows] = await pool.query('SELECT * FROM socio WHERE correo_electronico = ?', [email])
        return rows[0]
    }

    // Crear un nuevo usuario
    async createUser(name, surname, email, password){
        const [result] = await pool.query('INSERT INTO socio (nombre, apellidos, correo_electronico, contraseña) VALUES (?, ?, ?, ?)', [name, surname, email, password])
        return result.insertId
    };

    // Modificar un usuario existente
    async modifyUser(params){
        const { codigo_socio, nombre, apellidos, correo_electronico, contraseña, direccion, acceso } = params
        let query = 'UPDATE socio SET '
        const fields = []
        const values = []

        if (nombre) {
            fields.push('nombre = ?')
            values.push(nombre)
        }
        if (apellidos) {
            fields.push('apellidos = ?')
            values.push(apellidos)
        }
        if (correo_electronico) {
            fields.push('correo_electronico = ?')
            values.push(correo_electronico)
        }
        if (direccion) {
            fields.push('direccion = ?')
            values.push(direccion)
        }
        if (contraseña) {
            fields.push('contraseña = ?')
            values.push(contraseña)
        }
        if (acceso) {
            fields.push('acceso = ?')
            values.push(acceso)
        }

        if (fields.length === 0) {
            throw new Error('No hay campos para actualizar')
        }

        query += fields.join(', ')
        query += ' WHERE codigo_socio = ?'
        values.push(codigo_socio)

        const [result] = await pool.query(query, values)
        return result.affectedRows
    }

    // Eliminar un usuario
    async deleteUser(id){
        const [result] = await pool.query('DELETE FROM socio WHERE codigo_socio = ?', id)
        return result.affectedRows;
    }

    // Obtener todos los usuarios
    async getAllUsers(){
        const [rows] = await pool.query('SELECT * FROM socio')
        return rows
    }
}
export default User
